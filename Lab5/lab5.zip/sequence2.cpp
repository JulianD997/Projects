#include "sequence2.h"


sequence::sequence(size_type initial_capacity = DEFAULT_CAPACITY)
{
	used = 0;
	initial_capacity = capacity;
	current_index = 0;
	data = new value_type[capacity];
}


sequence::sequence(const sequence& source)
{
	capacity = new_capacity;
}


sequence::~sequence( )
{
	capacity = NULL;
}


void sequence::resize(size_type new_capacity)
{
}


void sequence::start( )
{
	current_index = 0;
}


void sequence::advance( )
{
	current_index++;
}


void sequence::insert(const value_type& entry)
{
	for (i = used; i < current_index; i--)
    {
      data[i]= data[i-1];
      data[current_index] = entry;
      used++;
    }
}


void sequence::attach(const value_type& entry)
{
	for (i = used; i < current_index; i--)
    {
      data[i] = data[i+1];
      data[current_index] = entry;
      used++;
    }
}


void sequence::remove_current( )
{
	for (i= current_index +1; i < used -1; i++)
    {
      data[i] = data[i+1];
      used--;
    }
}


void sequence::operator =(const sequence& source)
{
}


sequence::size_type sequence::size( ) const
{
	return used;
}

//Not sure if right
bool sequence::is_item( ) const
{
	if (current_index < used)
		return true;
}


sequence::value_type sequence::current( ) const
{
	return data;
}
