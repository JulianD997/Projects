#include <cstdlib>
#include <iostream>

using namespace std;

//Coded bu Julian Duran
//November 12th, 2019
//CS 3305L section 02

double sumover(unsigned int n){
    if (n != 0){
        return (1.00 / n) + sumover(n - 1);
    }
    else
        return 0;

}

int main()
{
    unsigned int n;
	cout << "the reciprocal of 0 is: "<< sumover(0) << endl; 
    cout << "the reciprocal of 1 is: "<< sumover(1) << endl;
    cout << "the reciprocal of 2 is: "<< sumover(2) << endl;
    cout << "the reciprocal of 3 is: "<< sumover(3) << endl;
    return 0;
}
