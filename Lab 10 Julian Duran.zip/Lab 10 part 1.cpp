#include <cstdlib>
#include <iostream>

using namespace std;

//Coded bu Julian Duran
//November 12th, 2019
//CS 3305L section 02

void recursion(int number, int i){
	if(number == 0){
    }
    
    else{
		cout <<string(i,' ');
        cout << "This was written by call number " << i << "." << endl;

        if (number > i){
            	recursion(number,i+1);
        }
        cout <<string(i,' ');
        cout << "This ALSO written by call number " << i << "." << endl;
    }
}

int main()
{
	unsigned int number;
	cout << "Please enter a number :" << endl;
	cin >> number;
	cout << endl;
	recursion(number,1);
}
